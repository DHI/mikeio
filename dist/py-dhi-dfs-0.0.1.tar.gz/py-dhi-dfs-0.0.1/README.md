# pydhi

Created by Marc-Etienne Ridler (mer@dhigroup.com)

This python library is intended to facilitate creating, reading and writing dfs0, dfs2, and dfs3 files.
It also supports some res1d funtionality.

Assumes MIKE installed already on the computer. Add install directory to PYTHONPATH from windows command line:

set PYTHONPATH=%PYTHONPATH%;"C:\Program Files (x86)\DHI\2019\bin\x64"


